import pygame
import random
import cv2
import numpy as np


class Rectangle(pygame.sprite.Sprite):
    def __init__(self, info):   #info: x, y(of middle point), w, h
        pygame.sprite.Sprite.__init__(self)
        self.image=pygame.Surface(info[2:])
        self.mask=pygame.mask.from_surface(self.image)
        self.rect=self.image.get_rect()
        self.rect.left, self.rect.top = info[0] - info[2]//2, info[1] - info[3]//2


class MovingObj(pygame.sprite.Sprite):
    def __init__(self, objtype, image_file, location, speed):
        # self, object type, image file, location, speed
        pygame.sprite.Sprite.__init__(self)
        self.objtype=objtype
        self.image=pygame.image.load(image_file)
        self.mask=pygame.mask.from_surface(self.image)
        self.rect=self.image.get_rect()
        self.rect.left, self.rect.top = location  # upper left location of image
        self.speed=speed
    
    def move(self):
        self.rect=self.rect.move(self.speed)
    
    def isOut(self):    
        if self.rect.top<0 or self.rect.bottom>height:
            return True
        return False


class FixedObj(pygame.sprite.Sprite):
    def __init__(self, objtype, image_file, location):
        #self, object type, image file, location
        pygame.sprite.Sprite.__init__(self)
        self.objtype=objtype
        self.image=pygame.image.load(image_file)
        self.rect=self.image.get_rect()
        self.rect.left, self.rect.top = location  # upper left location of image


def main():
    
    global is_playing, real_playing
    #pygame.mixer.music.load("Dad_and_Me.mp3")
    if is_playing and not real_playing:
        real_playing=True
        pygame.mixer.music.load("Dad_and_Me.mp3")
        pygame.mixer.music.play(-1)
    
    
    ddong_avoid=Rectangle((320, 180, 500, 100))
    high_scores=Rectangle((320, 300, 500, 100))
    quit_game=Rectangle((320, 420, 500, 100))
    music_onoff=Rectangle((600, 40, 40, 40))
    music_on=FixedObj("sound", "sound_on.png", (600-16, 40-16))
    music_off=FixedObj("sound", "sound_off.png", (600-16, 40-16))
    
    clock=pygame.time.Clock()
    
    while True:
        
        for event in pygame.event.get():
            if event.type==pygame.QUIT: return (QUIT_GAME,)
            elif event.type==pygame.MOUSEBUTTONDOWN: 
                x,y=event.pos
                if ddong_avoid.rect.collidepoint(x, y): return (PRE_PROCESS,)
                elif high_scores.rect.collidepoint(x, y): return (HIGH_SCORES,)
                elif quit_game.rect.collidepoint(x, y): return (QUIT_GAME,)                
                elif music_onoff.rect.collidepoint(x, y):
                    if is_playing: pygame.mixer.music.stop()
                    else: pygame.mixer.music.play(-1)
                    is_playing = not is_playing
        
        
        success, frame = capture.read()
        if success:
            frame_pg=cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            frame_pg=np.swapaxes(frame_pg, 0, 1)
            frame_pg=cv2.flip(frame_pg, 0)
            im=pygame.surfarray.make_surface(frame_pg)
            screen.blit(im, [0, 0])
        
        screen.blit(ddong_avoid.image, ddong_avoid.rect)
        screen.blit(high_scores.image, high_scores.rect)
        screen.blit(quit_game.image, quit_game.rect)
        if is_playing: screen.blit(music_on.image, music_on.rect)
        else: screen.blit(music_off.image, music_off.rect)
        
        
        ddong_avoid_surf=interface_font.render("Ddong Avoid", 1, (255,255,255))
        ddong_avoid_pos=[230,40]
        screen.blit(ddong_avoid_surf,ddong_avoid_pos)
        
        game_start_surf=interface_font.render("Game Start", 1, (255,255,255))
        game_start_pos=[240,145]
        screen.blit(game_start_surf,game_start_pos)
        
        high_score_surf=interface_font.render("High Score", 1, (255,255,255))
        high_score_pos=[250,265]
        screen.blit(high_score_surf,high_score_pos)
        
        quit_game_surf=interface_font.render("Quit Game", 1, (255,255,255))
        quit_game_pos=[250,385]
        screen.blit(quit_game_surf,quit_game_pos)
        
        
        pygame.display.flip()
        pygame.display.set_caption("fps: " + str(clock.get_fps()))
        clock.tick(60)
    

#generate random item
def itemKinds():
    star5s_prob=33 #invincible 5s
    reset_prob=66
    score2x_prob=99
    randomlynumber=random.randint(1,100)
    if randomlynumber<=star5s_prob:
        return "5s_star"
    elif randomlynumber<=reset_prob:
        return "reset"
    else:
        return "2x_score"



#in-game screen
def ingame():
    
    ingame_font = pygame.font.Font("Amatic-Bold.ttf", 30)
    
    heart_cur, heart_max = 3, 5
    
    gen_prob = 80
    dong_prob, heart_prob, coin_prob, item_prob = 50, 20, 15, 15
    
    img_dong = "1_Dong.png"
    img_heart = "2_Heart.png"
    img_bkheart = "3_BlackHeart.png"
    img_coin = "4_Hamburger.png"
    img_item = "5_item.png"
    img_item_star = "item_star.png"
    img_item_reset = "item_bomb.png"
    img_item_2x = "item_2x.png"
    
    dong_sz, heart_sz, coin_sz, item_sz = 32, 32, 32, 32
    
    dong_msp, dong_Msp = 5, 10
    heart_msp, heart_Msp = 7, 15
    coin_msp, coin_Msp = 10, 20
    item_msp, item_Msp = 10, 20
    
    time_star, time_2x = 0, 0
    maxtime_star, maxtime_2x = 100, 100
    
    
    movings = pygame.sprite.Group()
    
    clock = pygame.time.Clock()
    
    pygame.time.set_timer(pygame.USEREVENT+1, 2000)
    
    difficulty = 0

    diffname = ["Easy", "Normal", "Hard", "Extreme"]
    
    score = 0
    reallynoobj = 0
    
    itemtype, item_spr = None, None
    
    starstate = False # invincible
    score_mult = False # score 2x
    
    pygame.event.clear()
    
    while True:
        #event loop
        for event in pygame.event.get():
            
            #close window
            if event.type==pygame.QUIT: return (QUIT_GAME,)
            
            #random appearance
            elif event.type==pygame.USEREVENT+1:
                random1=random.randint(1,100)
                if random1>gen_prob:
                    pass
                else:
                    random2=random.randint(1,100)
                    if random2<=dong_prob:
                        movings.add(MovingObj("dong", img_dong, [random.randint(0, width-dong_sz), 0], [0, random.randint(dong_msp, dong_Msp)]))
                    elif random2<=dong_prob+heart_prob:
                        movings.add(MovingObj("heart", img_heart, [random.randint(0, width-heart_sz), 0], [0, random.randint(heart_msp, heart_Msp)]))
                    elif random2<=dong_prob+heart_prob+coin_prob:
                        movings.add(MovingObj("coin", img_coin, [random.randint(0, width-coin_sz), 0], [0, random.randint(coin_msp, coin_Msp)]))
                    else:
                        movings.add(MovingObj("item", img_item, [random.randint(0, width-item_sz), 0], [0, random.randint(item_msp, item_Msp)]))
        
        
        
        #camera input and lineize
        success, frame = capture.read()
        if success:

            frame_pg=cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            frame_pg=np.swapaxes(frame_pg, 0, 1)
            frame_pg=cv2.flip(frame_pg, 0)
            im=pygame.surfarray.make_surface(frame_pg)
            screen.blit(im, [0, 0])
            
            
            frame_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            frame_gray = cv2.flip(frame_gray, 1)
            thresh=cv2.adaptiveThreshold(frame_gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,cv2.THRESH_BINARY,15,8)
            #cv2.imshow('frame', thresh)
            
            
            rects=pygame.sprite.Group()
            noobj=True
            for x in range(4, width-4, 8):
                for y in range(4, height-4, 8):
                    if thresh[y][x] == 0:
                        rects.add(Rectangle((x, y, 8, 8)))
                        noobj=False

            #make item_frame more sensitive
            for x in range(560, 640, 4):
                for y in range(400, 480, 4):
                    if thresh[y][x] == 0:
                        rects.add(Rectangle((x,y,4,4)))
                        noobj=False
            if noobj:
                reallynoobj+=1
                if reallynoobj>5: return GAME_OVER, score
            else: reallynoobj=0
        
        
        #moves each MovingObj and collision check
        for spr in movings:
            spr.move()
            if spr.isOut(): movings.remove(spr)
            if pygame.sprite.spritecollide(spr, rects, pygame.sprite.collide_mask):
                movings.remove(spr)
                if spr.objtype=="dong":
                    if not starstate:
                        heart_cur-=1
                        if heart_cur==0:
                            return GAME_OVER, score
                elif spr.objtype=="heart": heart_cur=min(heart_cur+1, heart_max)
                elif spr.objtype=="coin": 
                    if score_mult:
                        score+=200 # 2x score
                    else:
                        score+=100
                elif spr.objtype=="item":
                    if itemtype==None:
                        itemtype=itemKinds()
                        if itemtype=="5s_star": 
                            item_spr_1=FixedObj("item", img_item_star, (600-16, 440-16))
                            item_spr_2=FixedObj("item", img_item_star, (40-16, 440-16))
                        elif itemtype=="reset": 
                            item_spr_1=FixedObj("item", img_item_reset, (600-16, 440-16))
                            item_spr_2=FixedObj("item", img_item_reset, (40-16, 440-16))
                        elif itemtype=="2x_score": 
                            item_spr_1=FixedObj("item", img_item_2x, (600-16, 440-16))
                            item_spr_2=FixedObj("item", img_item_2x, (40-16, 440-16))
                        
        
        item_frame_1=Rectangle((600, 440, 40, 40))
        item_frame_2=Rectangle((40, 440, 40, 40))
        
        #item
        if itemtype!=None:
            if pygame.sprite.spritecollide(item_frame_1, rects, False) or pygame.sprite.spritecollide(item_frame_2, rects, False):
                
                if itemtype=="5s_star":
                    starstate=True
                    time_star=0
                
                elif itemtype=="reset":
                    for spr in movings:
                        if spr.objtype=="dong": movings.remove(spr)
                
                elif itemtype=="2x_score":
                    score_mult=True
                    time_2x=0
                
                itemtype, item_spr = None, None
        
        if starstate:
            time_star+=1
            
            starstate_surf=ingame_font.render(f"INVINCIBLE", 1, (255,255,255))
            starstate_pos=[280, 0]
            screen.blit(starstate_surf, starstate_pos)
            
            pygame.draw.rect(screen, [255,255,255], [(width-maxtime_star)//2,40,maxtime_star,20], 2)
            pygame.draw.rect(screen, [0,0,0], [(width-maxtime_star)//2,40,time_star,20],0)
            
            if time_star>maxtime_star: starstate=False
            
        elif score_mult:
            time_2x+=1
            
            mult_surf=ingame_font.render(f"2X SCORE", 1, (255,255,255))
            mult_pos=[280, 0]
            screen.blit(mult_surf, mult_pos)
            
            pygame.draw.rect(screen, [255,255,255], [(width-maxtime_2x)//2,40,maxtime_2x,20], 2)
            pygame.draw.rect(screen, [0,0,0], [(width-maxtime_2x)//2,40,time_2x,20], 0)
            
            if time_2x>maxtime_2x: score_mult=False
        
        
        #moving object and item interface
        screen.blit(item_frame_1.image, item_frame_1.rect)
        screen.blit(item_frame_2.image, item_frame_2.rect)
        if itemtype!=None: 
            screen.blit(item_spr_1.image, item_spr_1.rect)
            screen.blit(item_spr_2.image, item_spr_2.rect)
        for spr in movings: screen.blit(spr.image, spr.rect)
        
    
        
        #heart(life) interface
        location=[None]*heart_max
        for i in range(heart_max):
            location[i]=width-(10+heart_sz)*(heart_max-i),10
            
            if i+1<=heart_cur: img=img_heart
            else: img=img_bkheart
            
            heart_fixed=FixedObj("heart", img, location[i])
            screen.blit(heart_fixed.image, heart_fixed.rect)
        
        
        #adjust score and difficulty
        #+1 score each frame
        if score_mult: score+=2 #2x score
        else: score+=1
        
        if score>=500 and difficulty==0:
            pygame.time.set_timer(pygame.USEREVENT+1, 1000) #every 3s in Normal difficulty
            difficulty=1
            dong_prob=70
            heart_prob=12
            coin_prob=9
            item_prob=9
        if score>=1500 and difficulty==1:
            pygame.time.set_timer(pygame.USEREVENT+1, 500) #every 2s in Hard difficulty
            difficulty=2
            dong_prob=70
            heart_prob=12
            coin_prob=9
            item_prob=9  
        if score>=5000 and difficulty==2:
            difficulty=3
            dong_prob=95
            heart_prob=0
            coin_prob=5
            item_prob=0
        
        #score and difficulty interface
        score_surf=ingame_font.render("Score: "+str(score), 1, (255,255,255))
        score_pos=[10,10]
        screen.blit(score_surf,score_pos)
        diff_surf=ingame_font.render("Difficulty: "+diffname[difficulty], 1, (255,255,255))
        diff_pos=[10,40]
        screen.blit(diff_surf,diff_pos)
        
        
        
        #post-processing
        pygame.display.flip()
        pygame.display.set_caption("fps: " + str(clock.get_fps()))
        clock.tick(60)    



#game over screen
def gameover(score):
    
    global is_playing, real_playing
    
    clock=pygame.time.Clock()
    #pygame.mixer.music.stop()
    real_playing=False
    if is_playing:
        pygame.mixer.music.load("game_over.wav")
        pygame.mixer.music.play()
    
    
    while True:
        
        submit=[width*1//16, height*2//3, width*3//8, height*1//4]
        gohome=[width*9//16, height*2//3, width*3//8, height*1//4]
        
        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                return (QUIT_GAME,)
            elif event.type==pygame.MOUSEBUTTONDOWN:
                x, y=event.pos
                if submit[0]<=x<=submit[0]+submit[2] and \
                   submit[1]<=y<=submit[1]+submit[3]:
                    return (SUBMIT,score)
                elif gohome[0]<=x<=gohome[0]+gohome[2] and \
                     gohome[1]<=y<=gohome[1]+gohome[3]:
                    return (MAIN,)
        
        success, frame = capture.read()
        if success:
            frame_pg=cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            frame_pg=np.swapaxes(frame_pg, 0, 1)
            frame_pg=cv2.flip(frame_pg, 0)
            im=pygame.surfarray.make_surface(frame_pg)
            screen.blit(im, [0, 0])
        
        
        score_surf=interface_font.render("Score: "+str(score),1,(0,0,0))
        score_pos=[260,200]
        screen.blit(score_surf,score_pos)
        
        gameover_surf=interface_font.render("GAME OVER",1,(0,0,0))
        gameover_pos=[260,150]
        screen.blit(gameover_surf,gameover_pos)
        
        pygame.draw.rect(screen, [0,0,0], submit, 0)
        submit_surf=interface_font.render("Submit Score",1,(255,255,255))
        submit_pos=[submit[0]+40, submit[1]+25]
        screen.blit(submit_surf,submit_pos)
        
        pygame.draw.rect(screen, [0,0,0], gohome, 0)    
        gohome_surf=interface_font.render("Go to Home",1,(255,255,255))
        gohome_pos=[gohome[0]+50, gohome[1]+25]
        screen.blit(gohome_surf,gohome_pos)
        
        
        pygame.display.flip()
        pygame.display.set_caption("fps: " + str(clock.get_fps()))
        clock.tick(10)    


def submit(score):
    
    global hs
    
    string=""
    submit_score=Rectangle((320, 240, 500, 100))
    clock=pygame.time.Clock()

    while True:
    
        for event in pygame.event.get():
            if event.type==pygame.KEYDOWN:
                if event.key==pygame.K_RETURN:
                    hs.append((string,score))
                    hs.sort(key=lambda x: x[1], reverse=True)
                    if len(hs)>10:
                        hs=hs[:10]
                    return (MAIN,)
                elif event.key==pygame.K_BACKSPACE:
                    if len(string)>0:
                        string=string[:len(string)-1]
                    else:
                        pass
                elif 'a'<=chr(event.key)<='z' or '0'<=chr(event.key)<='9':
                    string=string+chr(event.key)
    
    
        success, frame = capture.read()
    
        if success:
            frame_pg=cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            frame_pg=np.swapaxes(frame_pg, 0, 1)
            frame_pg=cv2.flip(frame_pg, 0)
            im=pygame.surfarray.make_surface(frame_pg)
            screen.blit(im, [0, 0])
    
    
        screen.blit(submit_score.image, submit_score.rect)
    
        submit_score_surf=interface_font.render(string, 1, (255,255,255))
        submit_score_pos=[80,210]
        screen.blit(submit_score_surf,submit_score_pos)
    
        pygame.display.flip()
        pygame.display.set_caption("fps: " + str(clock.get_fps()))
        clock.tick(10)
        

def preprocess():
    
    clock=pygame.time.Clock()
    
    pygame.mixer.music.load("Start.mp3")
    pygame.mixer.music.play()    
    #i=0
    while True:
        #i+=1
        #camera read
        success, frame = capture.read()
        if success:

            frame_pg=cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            frame_pg=np.swapaxes(frame_pg, 0, 1)
            frame_pg=cv2.flip(frame_pg, 0)
            im=pygame.surfarray.make_surface(frame_pg)
            screen.blit(im, [0, 0])
            
        
        if not pygame.mixer.music.get_busy():
            pygame.mixer.music.load("Dad_and_Me.mp3")
            if is_playing:
                pygame.mixer.music.play(-1)                
            return (IN_GAME,)
        
        #if i>200:
        #    return (IN_GAME,)
            
        pygame.display.flip()
        clock.tick(60)

def highscores():
    
    ingame_font=pygame.font.Font("Amatic-Bold.ttf", 30)
    
    x1, x2, x3 = 28, 72, 421
    y = lambda i: 56+42*i
    
    x_sz1, x_sz2, x_sz3 = 34, 340, 188
    y_sz = 34
    
    clock=pygame.time.Clock()
    
    while True:
        for event in pygame.event.get():
            if event.type==pygame.QUIT: return (QUIT_GAME,)
            elif event.type==pygame.MOUSEBUTTONDOWN: 
                return (MAIN,)
    
        success, frame = capture.read()
        
        if success:
            frame_pg=cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            frame_pg=np.swapaxes(frame_pg, 0, 1)
            frame_pg=cv2.flip(frame_pg, 0)
            im=pygame.surfarray.make_surface(frame_pg)
            screen.blit(im, [0, 0])
            
        hs_surf = ingame_font.render("High Scores", 1, (255,255,255))
        hs_pos = [261,20]
        screen.blit(hs_surf, hs_pos)
        
        for i in range(10):
            pygame.draw.rect(screen, [0,0,0], [x1,y(i),x_sz1,y_sz], 0)
            pygame.draw.rect(screen, [0,0,0], [x2,y(i),x_sz2,y_sz], 0)
            pygame.draw.rect(screen, [0,0,0], [x3,y(i),x_sz3,y_sz], 0)
        
        for i in range(len(hs)):
            order_surf = ingame_font.render(str(i+1), 1, (255,255,255))
            order_pos = [x1+10,y(i)]
            screen.blit(order_surf, order_pos)
            
            id_surf = ingame_font.render(hs[i][0], 1, (255,255,255))
            id_pos = [x2,y(i)]
            screen.blit(id_surf, id_pos)
            
            score_surf = ingame_font.render(str(hs[i][1]), 1, (255,255,255))
            score_pos = [x3,y(i)]
            screen.blit(score_surf, score_pos)
        
        pygame.display.flip()
        pygame.display.set_caption("fps: " + str(clock.get_fps()))
        clock.tick(10)            
    
    

pygame.mixer.pre_init(44100, 16, 2, 4096)
pygame.init()


QUIT_GAME=-1
MAIN=0
PRE_PROCESS=1
IN_GAME=2
GAME_OVER=3
SUBMIT=4
HIGH_SCORES=5


f=open("highscores.txt", "r")
hs=[]
lines=f.readlines()
for line in lines:
    name, score=line.split(";")
    #score=score[:-1]
    hs.append((name, int(score)))

f.close()

prev_score=None

capture=cv2.VideoCapture(0)
#capture=cv2.VideoCapture(1)
width=int(capture.get(cv2.CAP_PROP_FRAME_WIDTH))
height=int(capture.get(cv2.CAP_PROP_FRAME_HEIGHT))
size=width, height
screen=pygame.display.set_mode(size,pygame.FULLSCREEN)
#screen=pygame.display.set_mode(size)

interface_font=pygame.font.Font("Amatic-Bold.ttf", 50)

is_playing=True
real_playing=True
pygame.mixer.music.load("Dad_and_Me.mp3")
pygame.mixer.music.play(-1)

game_info=(MAIN,)
while True:
    window=game_info[0]
    if window==QUIT_GAME: break
    elif window==MAIN: game_info=main()
    elif window==PRE_PROCESS: game_info=preprocess()
    elif window==IN_GAME: game_info=ingame()
    #elif window==IN_GAME or window==PRE_PROCESS: game_info=ingame()
    elif window==GAME_OVER: game_info=gameover(game_info[1])
    elif window==SUBMIT: game_info=submit(game_info[1])
    elif window==HIGH_SCORES: game_info=highscores()
    
pygame.quit()
capture.release()
cv2.destroyAllWindows()

f=open("highscores.txt", "w")
for i in hs:
    data=i[0]+";"+str(i[1])+"\n"
    f.write(data)
f.close()